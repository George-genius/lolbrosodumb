ace.define("ace/theme/vscode-dark", ["require", "exports", "module", "ace/lib/dom"], function(require, exports, module) {
    var dom = require("../lib/dom");

    exports.isDark = true;
    exports.cssClass = "ace-vscode-dark";
    exports.cssText = `
    .ace-vscode-dark {
        color: #d4d4d4;
        background-color: #1e1e1e;
    }

    .ace-vscode-dark .ace_gutter {
        background: #252526;
        color: #858585;
        border-right: none;
    }

    .ace-vscode-dark .ace_gutter-active-line {
        background-color: #2a2d2e;
    }

    .ace-vscode-dark .ace_print-margin {
        width: 1px;
        background: #2e2e2e;
    }

    .ace-vscode-dark .ace_cursor {
        color: #aeafad;
    }

    .ace-vscode-dark .ace_hidden-cursors .ace_cursor {
        visibility: hidden;
    }

    .ace-vscode-dark .ace_marker-layer .ace_selection {
        background: #264f78;
    }

    .ace-vscode-dark .ace_marker-layer .ace_active-line {
        background: #2a2a2a;
    }

    .ace-vscode-dark .ace_marker-layer .ace_selected-word {
        border: 1px solid #264f78;
    }

    .ace-vscode-dark .ace_invisible {
        color: #404040;
    }

    .ace-vscode-dark .ace_constant.ace_numeric,
    .ace-vscode-dark .ace_constant.ace_language,
    .ace-vscode-dark .ace_constant.ace_character,
    .ace-vscode-dark .ace_constant.ace_other {
        color: #b5cea8; /* numbers */
    }

    .ace-vscode-dark .ace_keyword,
    .ace-vscode-dark .ace_storage {
        color: #569cd6; /* for, if, int, static... */
    }

    .ace-vscode-dark .ace_keyword.ace_operator {
        color: #d4d4d4; /* keep operators neutral like VS Code */
    }

    .ace-vscode-dark .ace_variable {
        color: #9cdcfe; /* normal identifiers */
    }

    .ace-vscode-dark .ace_support.ace_function,
    .ace-vscode-dark .ace_entity.ace_name.ace_function {
        color: #dcdcaa; /* function names */
    }

    .ace-vscode-dark .ace_support.ace_class,
    .ace-vscode-dark .ace_support.ace_type {
        color: #4ec9b0;
    }

    .ace-vscode-dark .ace_string {
        color: #ce9178;
    }

    .ace-vscode-dark .ace_comment {
        color: #6a9955;
        font-style: normal;
    }

    .ace-vscode-dark .ace_entity.ace_name.ace_tag,
    .ace-vscode-dark .ace_meta.ace_tag {
        color: #569cd6;
    }

    .ace-vscode-dark .ace_entity.ace_other.ace_attribute-name {
        color: #9cdcfe;
    }

    .ace-vscode-dark .ace_punctuation,
    .ace-vscode-dark .ace_punctuation.ace_tag {
        color: #d4d4d4;
    }

    .ace-vscode-dark .ace_fold {
        background-color: #569cd6;
        border-color: #d4d4d4;
    }

    .ace-vscode-dark .ace_bracket {
        color: #d4d4d4;
    }

    .ace-vscode-dark .ace_indent-guide {
        box-shadow: none;
        background: transparent;
        border-right: 1px solid #404040;
        margin-right: -1px;
    }

    .ace-vscode-dark .ace_marker-layer .ace_bracket {
        margin: -1px 0 0 -1px;
        border: 1px solid #88888855;
    }

    .ace-vscode-dark .ace_marker-layer .ace_whitespace {
        background: none;
    }

    .ace-vscode-dark .ace_marker-layer .ace_error {
        background-color: #f4474733;
        position: absolute;
    }

    .ace-vscode-dark .ace_invalid {
        color: #f44747;
    }

    .ace-vscode-dark .ace_support.ace_constant,
    .ace-vscode-dark .ace_support.ace_variable {
        color: #9cdcfe;
    }

    .ace-vscode-dark .ace_meta.ace_space,
    .ace-vscode-dark .ace_meta.ace_other {
        color: #d4d4d4;
    }
/* TYPES: vector, string, map */
.ace-vscode .ace_support.ace_type {
    color: #4ec9b0 !important;
}

/* FUNDAMENTAL TYPES: int, long, bool */
.ace-vscode .ace_storage.ace_type {
    color: #569cd6 !important; /* same blue as VS Code */
}

/* < and > in templates should NOT be bright */
.ace-vscode .ace_punctuation.ace_operator {
    color: #d4d4d4 !important;
}

/* Stronger function color */
.ace-vscode .ace_entity.ace_name.ace_function,
.ace-vscode .ace_support.ace_function {
    color: #dcdcaa !important;
    font-weight: normal !important;
}

/* Comments stronger */
.ace-vscode .ace_comment {
    color: #6a9955 !important;
}

    `;

    dom.importCssString(exports.cssText, exports.cssClass);
});
